﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Webapi_project_1.Model
{
    public class Paging
    {
        public int start { get; set; }
        public int end { get; set; }
       

    }
}
