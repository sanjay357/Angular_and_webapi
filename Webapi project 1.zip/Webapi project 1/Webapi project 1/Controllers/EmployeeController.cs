﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Webapi_project_1.Interface;
using Webapi_project_1.Model;
using Microsoft.AspNet.OData;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Webapi_project_1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize (AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
  
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeCouchbaseService _service;
        private readonly ILogger<EmployeeController> logger;

        public EmployeeController(IEmployeeCouchbaseService service, ILogger<EmployeeController> logger)
        {
            _service = service;

            this.logger = logger;
            logger.LogInformation( "NLog injected into EmployeeController");
        }
        // GET: api/<EmployeeController>
        [HttpGet]
     //  [EnableQuery()]
     [Authorize (Roles ="superadmin,user,admin")]
        public async Task<EmployeeCollection> Get([FromQuery] Paging paging  )
        {
            EmployeeCollection emp = new EmployeeCollection();
            logger.LogInformation("geting  all Employees");
            var couchClient = await _service.Initialize();
            var employees = await _service.GetEmployees(couchClient ,paging);
            var employee = await _service.GetEmployeescount(couchClient);
            if (employees == null)
            {
                logger.LogWarning("Can't get Employees");

            }
            int count= employee.Count;
           

            emp.employees = employees;
            emp.employeeCount = count;

           return emp;
        }



        // GET api/<EmployeeController>/5
        [HttpGet("{id}")]
        [Authorize (Roles ="superadmin,admin,user")]
        ////[HttpGet("{department}/{id}")]
        public async Task<Employees> Get(int id)
        {
            
            var couchClient = await _service.Initialize();
            var employees = await _service.GetEmployeById(couchClient, id);
            if (employees.id == 0)
            {
                logger.LogWarning($"Employee With Id- {id} not found");
                logger.LogError("This is an error");
                return null;
            }
            return employees;


        }

        // POST api/<EmployeeController>
        [HttpPost]
        [Authorize(Roles = "superadmin,admin")]
        public async Task Post([FromBody] Employees value)
        {
            logger.LogInformation($"Posting this  {value} Employee");
            var couchClient = await _service.Initialize();
            await _service.PostEmploye(couchClient, value);

    

        } 

        //update
        // PUT api/<EmployeeController>/5
        [HttpPut("{id}")]
        [Authorize (Roles ="superadmin,admin")]
        public async Task<Employees> Put(int id, [FromBody] Employees value)
        {
            logger.LogInformation($"Updating  this Id-{id}");
            var couchClient = await _service.Initialize();
            await _service.PutEmployeById(couchClient, id,value);

            return null;
           
        }

        // DELETE api/<EmployeeController>/5
        [HttpDelete("{id}")]
        [Authorize (Roles ="superadmin")]
        public async Task<Employees> Delete(int id)
        {
            logger.LogInformation($"Deleting this Id-{id}");
            var couchClient = await _service.Initialize();
            await _service.DeleteEmployeById(couchClient, id);

            return null;


        }
    }
}
