export class Tokenn {
    unique_name:string;
 
  exp:number;
 
}
