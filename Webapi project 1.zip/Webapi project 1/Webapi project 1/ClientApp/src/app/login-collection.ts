import { UserInfo } from './Login/user-info';

export class LoginCollection {
    loginDetails: UserInfo[];
    token:string;

}
