import { Employeedetails } from './employeedetails';

describe('Employeedetails', () => {
  it('should create an instance', () => {
    expect(new Employeedetails()).toBeTruthy();
  });
});
